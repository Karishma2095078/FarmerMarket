﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Npgsql;

namespace FarmerMarket
{
    /// <summary>
    /// Interaction logic for Admin.xaml
    /// </summary>
    public partial class Admin : Window
    {
        //Update data in gridview
        private NpgsqlDataAdapter npgsqlDataAdapter;
        private DataTable dt;

        //***************** Database Connection **********************

        //Generate connection string
        private static string getConnectionString()
        {
            string host = "Host=localhost;";
            string port = "Port=5432;";
            string dbName = "Database=FarmerMarket;";
            string userName = "Username=postgres;";
            string password = "Password=postgres;";

            string connectionString = string.Format("{0}{1}{2}{3}{4}", host, port, dbName, userName, password);
            return connectionString;
        }

        //***************** Establish Connection **********************

        //Connection Adapter: helps to connect to a postgreSQL database
        public static NpgsqlConnection con;

        //Command Adapter: helps to send/execute any command in the databse
        public static NpgsqlCommand cmd;

        private static void establishConnection()
        {
            try
            {
                con = new NpgsqlConnection(getConnectionString());

            } catch(NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
                System.Windows.Application.Current.Shutdown();
            }
        }

        public Admin()
        {
            InitializeComponent();

            establishConnection();

            try
            {
                con.Open();

                //Select query
                string Query = "Select * from products";

                cmd = new NpgsqlCommand(Query, con);

                npgsqlDataAdapter = new NpgsqlDataAdapter(cmd);
                dt = new DataTable();
                npgsqlDataAdapter.Fill(dt);

                //The following line will help us to add the values to the dataGrid view
                dataGrid.ItemsSource = dt.AsDataView();

                //This will perform the dynamic binding, It will update the grid
                DataContext = npgsqlDataAdapter;

                con.Close();

            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //Update data in gridview
        private void RefreshDataGrid()
        {
            dt.Clear();
            npgsqlDataAdapter.Fill(dt);
            dataGrid.Items.Refresh();
        }

        //***************** Insert Operation to Database **********************
        private void BtnInsert_Click(object sender, RoutedEventArgs e)
        {
            //First step is to call the connection establishment method
            establishConnection();

            try
            {
                con.Open();

                string Query = "insert into products values(@productId, @productName, @amount, @price)";

                cmd = new NpgsqlCommand(Query, con);
                cmd.Parameters.AddWithValue("@productId", int.Parse(TextProductID.Text));
                cmd.Parameters.AddWithValue("@productName", TextProductName.Text);
                cmd.Parameters.AddWithValue("@amount", int.Parse(TextAmount.Text));
                cmd.Parameters.AddWithValue("@price", decimal.Parse(TextPrice.Text));
                cmd.ExecuteNonQuery();

                // Update the database with the changes
                npgsqlDataAdapter.Update(dt);

                MessageBox.Show("Inserted successfully in the Database");

                TextProductID.Text = String.Empty;
                TextProductName.Text = String.Empty;
                TextAmount.Text = String.Empty;
                TextPrice.Text = String.Empty;

                con.Close();

                // Refresh the DataGrid to display the updated data
                RefreshDataGrid();

            } catch(NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //***************** Select Operation to Database **********************
        private void BtnSelect_Click(object sender, RoutedEventArgs e)
        {
            establishConnection();

            try
            {
                con.Open();

                string Query = "select * from products";

                cmd = new NpgsqlCommand(Query, con);

                NpgsqlDataAdapter npgsqlDataAdapter = new NpgsqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                npgsqlDataAdapter.Fill(dt);
                dataGrid.ItemsSource = dt.AsDataView();
                DataContext = npgsqlDataAdapter;

                con.Close();

            } catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //***************** Update Operation to Database **********************
        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            establishConnection();

            try
            {
                con.Open();

                //***** PostgresSQL is case-sensitive, it will convert all letetrs to lower case,
                //in our table column name productName will convert to productname will not match 
                //when run the code, that's why need to write it in between \"productName\" *****

                string Query = "update products set \"productName\"=@productName,amount=@amount,price=@price" +
                        " where \"productId\"=@productId";

                cmd = new NpgsqlCommand(Query, con);
                cmd.Parameters.AddWithValue("@productName", TextProductName.Text);
                cmd.Parameters.AddWithValue("@amount", int.Parse(TextAmount.Text));
                cmd.Parameters.AddWithValue("@price", decimal.Parse(TextPrice.Text));
                cmd.Parameters.AddWithValue("@productId", int.Parse(TextProductID.Text));
                cmd.ExecuteNonQuery();

                // Update the database with the changes
                npgsqlDataAdapter.Update(dt);

                MessageBox.Show("Updated successfully in the Database");

                TextProductID.Text = String.Empty;
                TextProductName.Text = String.Empty;
                TextAmount.Text = String.Empty;
                TextPrice.Text = String.Empty;

            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();

                // Refresh the DataGrid to display the updated data
                RefreshDataGrid();
            }
        }

        //***************** Delete Operation to Database **********************
        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            establishConnection();

            try
            {
                con.Open();

                string Query = "delete from products where \"productId\"=@productId";

                cmd = new NpgsqlCommand(Query, con);
                cmd.Parameters.AddWithValue("@productId", int.Parse(TextProductID.Text));
                cmd.ExecuteNonQuery ();

                // Update the database with the changes
                npgsqlDataAdapter.Update(dt);

                MessageBox.Show("Deleted successfully in the Database");

                TextProductID.Text = String.Empty;

                con.Close();

                // Refresh the DataGrid to display the updated data
                RefreshDataGrid();
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void backbtn_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            this.Close();
            mainWindow.Show();
        }
    }
}
