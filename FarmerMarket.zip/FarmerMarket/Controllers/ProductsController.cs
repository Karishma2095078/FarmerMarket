﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Npgsql;
using System.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;


namespace FarmerMarket.Controllers
{
    internal class ProductsController
    {
        private static string GetConnectionString()
        {
            string host = "Host=localhost;";
            string port = "Port=5432;";
            string dbName = "Database=FarmerMarket;";
            string userName = "Username=postgres;";
            string password = "Password=postgres;";

            string connectionString = string.Format("{0}{1}{2}{3}{4}", host, port, dbName, userName, password);
            return connectionString;
        }

        private static NpgsqlConnection GetDbConnection()
        {
            var connection = new NpgsqlConnection(GetConnectionString());
            connection.Open();
            return connection;
        }

        [HttpGet]
        public IActionResult GetAllProducts()
        {
            using (var connection = GetDbConnection())
            {
                var query = "SELECT * FROM products";
                var command = new NpgsqlCommand(query, connection);

                var adapter = new NpgsqlDataAdapter(command);
                var dataTable = new DataTable();
                adapter.Fill(dataTable);

                return Ok(dataTable);
            }
        }

        [HttpPost]
        public IActionResult AddProduct(ProductDto product)
        {
            using (var connection = GetDbConnection())
            {
                var query = "INSERT INTO products (productId, productName, amount, price) VALUES (@productId, @productName, @amount, @price)";
                var command = new NpgsqlCommand(query, connection);
                command.Parameters.AddWithValue("@productId", product.ProductId);
                command.Parameters.AddWithValue("@productName", product.ProductName);
                command.Parameters.AddWithValue("@amount", product.Amount);
                command.Parameters.AddWithValue("@price", product.Price);
                command.ExecuteNonQuery();

                return Ok();
            }
        }

        [HttpPut("{productId}")]
        public IActionResult UpdateProduct(int productId, ProductDto product)
        {
            using (var connection = GetDbConnection())
            {
                var query = "UPDATE products SET productName = @productName, amount = @amount, price = @price WHERE productId = @productId";
                var command = new NpgsqlCommand(query, connection);
                command.Parameters.AddWithValue("@productName", product.ProductName);
                command.Parameters.AddWithValue("@amount", product.Amount);
                command.Parameters.AddWithValue("@price", product.Price);
                command.Parameters.AddWithValue("@productId", productId);
                command.ExecuteNonQuery();

                return Ok();
            }
        }

        [HttpDelete("{productId}")]
        public IActionResult DeleteProduct(int productId)
        {
            using (var connection = GetDbConnection())
            {
                var query = "DELETE FROM products WHERE productId = @productId";
                var command = new NpgsqlCommand(query, connection);
                command.Parameters.AddWithValue("@productId", productId);
                command.ExecuteNonQuery();

                return Ok();
            }
        }
}
